import React, { useCallback, useMemo, useRef, useState } from 'react';
import { render } from 'react-dom';
import { AgGridReact } from "ag-grid-react";

import { TabView, TabPanel } from 'primereact/tabview';
import { Button } from 'primereact/button';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faAngleDown, faAngleUp, faPlus } from '@fortawesome/free-solid-svg-icons';
import { BreadCrumb } from 'primereact/breadcrumb'; 
import MoodRenderer from './moodRenderer.jsx';
import TotalValueRenderer from './totalValueRenderer.jsx';
import '../styles/css/style.css';



const GridExample = () => {
    const gridRef = useRef();
    // const containerStyle = useMemo(() => ({ width: '100%', height: '100%' }), []);
    // const gridStyle = useMemo(() => ({ height: '100%', width: '100%' }), []);
    const [rowData, setRowData] = useState([
        { id: 'aa', make: '0121', key: 'EDI-A08', model: 'Celica', type: '.xls', desc: 'PR Coating(ArF/ EUV, UDO)', owner: 'KP0T11', scope: 'de88', date: '24/08/2008', tcount: 3 },
        { id: 'bb', make: '0125', key: 'EDI-A11', model: 'Mondeo', type: '.ppt', desc: 'PR Coating (KrF / Arf / Imme)', owner: 'KP0T11', scope: 'de88', date: '24/08/2008', tcount: 2 },
        { id: 'cc', make: '0124', key: 'EDI-A14', model: 'Boxster', type: '.pdf', desc: '', owner: 'PA091', scope: 'de88', date: '24/08/2008', tcount: 5 },
        { id: 'dd', make: '0126', key: 'EDI-D11', model: 'Angel', type: '.xls', desc: 'Use for ETCH1 pre-hookup tools', owner: 'KF0T21', scope: 'de88', date: '24/08/2008', tcount: 6 },
        { id: 'ee', make: '0128', key: 'EDI-A17', model: 'Challanger', type: '.doc', desc: 'PR Coating', owner: 'KP0T11', scope: 'de88', date: '24/08/2008', tcount: 0 },
        { id: 'ff', make: '0150', key: 'PHK', model: 'Kristin', type: '.xls', desc: '', owner: 'KP02A1', scope: 'de88', date: '24/08/2008', tcount: 1 },
    ]);
    const [columnDefs, setColumnDefs] = useState([
        { headerName: 'Fab', field: 'make', minWidth: 120, checkboxSelection: true },
        { headerName: 'Dept', field: 'key'},
        { headerName: 'Task File Name', field: 'model' },
        {
            headerName: 'File Type',
            cellRenderer: MoodRenderer, 
            field: 'type',
        },       
        { headerName: 'Task Description', field: 'desc' },
        { headerName: 'Owner', field: 'owner' },
        { headerName: 'Task Scope', field: 'scope' },
        { headerName: 'Update DT', field: 'date' },
        {
            headerName: 'Action',
            field: 'action',
            cellRenderer: TotalValueRenderer
        }
    ]);
    const defaultColDef = useMemo(() => {
        return {
            flex: 1,
            editable: true,
            sortable: true,
            filter: true,
        };
    }, []);
    const getRowId = useCallback(function (params) {
        return params.data.id;
    }, []);

    const updateSort = useCallback(() => {
        gridRef.current.api.refreshClientSideRowModel('sort');
    }, []);

    const updateFilter = useCallback(() => {
        gridRef.current.api.refreshClientSideRowModel('filter');
    }, []);

    


    //BreadCrumb
    const items = [
        { label: 'SOP Summary > ', url: '/' },
        { label: 'SOP Management For Task : 0124', url: './p2' }
    ]; 

    return (
        <div className='sop'>
            <div className='topMenu'>
                <div className='breadcrumb'>
                    <BreadCrumb model={items}/>
                    <Button className='previous' onClick={() => {
                        setIsDetail(false);
                        fetchTableDate();
                    }}><FontAwesomeIcon icon={faAngleUp} />
                    </Button>
                    <Button className='next' onClick={() => {
                        setIsDetail(false);
                        fetchTableDate();
                    }}><FontAwesomeIcon icon={faAngleDown} />
                    </Button>
                </div>
                <div className='create'>
                    <Button onClick={() => {
                        setIsDetail(false);
                        fetchTableDate();
                    }}>
                        <FontAwesomeIcon icon={faPlus} />
                    </Button>
                </div>
            </div>
            <div className='view'>
                <div className='grid-table ag-theme-alpine'>
                    <AgGridReact
                        ref={gridRef}
                        rowData={rowData}
                        columnDefs={columnDefs}
                        defaultColDef={defaultColDef}
                        animateRows={true}
                        getRowId={getRowId}
                        rowSelection={'multiple'}
                        suppressRowClickSelection={true}
                        suppressAggFuncInHeader={true}
                    ></AgGridReact>
                    
                </div>
            </div>
        </div>
        
    );
};

// const Test = () => {
//     return (<div>123</div>);
// }
export default GridExample;

