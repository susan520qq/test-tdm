import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";

import { AgGridReact } from 'ag-grid-react';
// import { ClientSideRowModelModule } from '@ag-grid-community/client-side-row-model';

import 'ag-grid-community/dist/styles/ag-grid.css';
import 'ag-grid-community/dist/styles/ag-theme-alpine.css';

import CustomHeader from "./CustomHeader";
// import CustomHeader from "./Header";
import FullWidthCellRenderer from '../Control/Control'
import { RadioButton } from 'primereact/radiobutton';
 
import icons from '../styles/img/icon.svg';


const GridTable: React.FC<GridTableProps> = (props: GridTableProps) => {
    const gridRef = useRef<any>();

    const [columnDefs, setColumnDefs]: any[] = useState([]);
    const [rowData, setRowData]: any = useState();
    const [gridAPI, setGridAPI] = useState<any>();
    const [isExpand, setIsExpand] = useState(false)
    const [isShrink, setIsShrink] = useState(false)

    const [defaultColDef] = useState({
        resizable: false,
        wrapText: true,
        autoHeight: true,
        // minWidth: 100,
        sortable: true,
        // pagination: true,
        // paginationAutoPageSize: 2,
        suppressAutoSize: true,
        suppressSizeToFit: true,
        filter: 'agTextColumnFilter',
        // Default Use filter in first row
        // suppressMenu: true,
        // floatingFilter: true,
        alwaysShowHorizontalScroll: true,
        alwaysShowVerticalScroll: true,
        headerComponentParams: {
            enableMenu: true,
        },
    });

    const components = useMemo(() => {
        return {
            agColumnHeader: CustomHeader,
        };
    }, []);

    useEffect(() => {
        createColumns();
    });

    useEffect(() => {
        getData();
    }, [props.dataDefs.data])

    const onGridReady = (api: any) => {
        setGridAPI(api)
    }

    const getData = () => {
        if (props.dataDefs.data) {
            setRowData(props.dataDefs.data);
        }
    }

    const createColumns = () => {
        setColumnDefs(props.columnDefs.groups)
    }

    const handleClickExpand = () => {
        if (props.getExpandColumns) {
            const newColumnsDef = props.getExpandColumns(!isExpand);
            gridRef.current.api.setColumnDefs(newColumnsDef)
            setIsExpand(!isExpand);
        }
    }

    const handleClickShrink = () => {
        if (props.getShrinkColumns) {
            const newColumnsDef = props.getShrinkColumns(!isShrink);
            gridRef.current.api.setColumnDefs(newColumnsDef)
            setIsShrink(!isShrink);
        }
    }

    const isFullWidth = (data: any) => {
        return data.fullWitdth
    }

    const isFullWidthCell = useCallback(function (rowNode) {
        return isFullWidth(rowNode.data);
    }, []);

    const fullWidthCellRenderer = useMemo(() => {
        return FullWidthCellRenderer;
    }, []);

    const getRowHeight = useCallback(function (params) {
        // return 100px height for full width rows
        if (isFullWidth(params.data)) {
            return 60;
        }

    }, []);



    const Icon = (props: any) => {
        return (
            <svg
                xmlns="http://www.w3.org/2000/svg"
                xmlnsXlink="http://www.w3.org/2000/xlink"
                className={`icon-${props.name}`}
            >
                <use xlinkHref={`${icons}#${props.name}`} />
            </svg>
        )
    }

    return (
        <div className='grid-table ag-theme-alpine' style={{ height: "90%" }}>

         

            <AgGridReact
                ref={gridRef}
                onGridReady={onGridReady}
                rowData={rowData}
                columnDefs={columnDefs}
                defaultColDef={defaultColDef}
                components={components}
                getRowHeight={getRowHeight}
                isFullWidthCell={isFullWidthCell}
                fullWidthCellRenderer={fullWidthCellRenderer}
                onRowSelected={()=>{}}
                onSelectionChanged={()=>{}}
            />


        </div> 
    );
}

export default GridTable;