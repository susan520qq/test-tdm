import React, { useState } from "react";
import { RadioButton } from "primereact/radiobutton";
import { Dropdown } from "primereact/dropdown";

const cities = [
    { name: "New York", code: "NY" },
    { name: "Rome", code: "RM" },
    { name: "London", code: "LDN" },
    { name: "Istanbul", code: "IST" },
    { name: "Paris", code: "PRS" },
];

const Demo = () => {
    const [inputValue, setInputValue] = useState("");
    const [radioValue, setRadioValue] = useState(null);
    const [dropValue, setDropValue] = useState();

    return (
        <div>
            <div>
                <h3>Input</h3>
                <input
                    value={inputValue}
                    onChange={(e) => {
                        setInputValue(e.target.value);
                    }}
                />
            </div>
            <div>
                <h3>Radio</h3>
                <div className="p-field-radiobutton">
                    <RadioButton
                        inputId="city1"
                        name="city"
                        value="Chicago"
                        onChange={(e) => setRadioValue(e.value)}
                        checked={radioValue == "Chicago"}
                    />
                    <label htmlFor="city1">Chicago</label>
                </div>
                <div className="p-field-radiobutton">
                    <RadioButton
                        inputId="city2"
                        name="city"
                        value="Los Angeles"
                        onChange={(e) => setRadioValue(e.value)}
                        checked={radioValue == "Los Angeles"}
                    />
                    <label htmlFor="city2">Los Angeles</label>
                </div>
                <div className="p-field-radiobutton">
                    <RadioButton
                        inputId="city3"
                        name="city"
                        value="New York"
                        onChange={(e) => setRadioValue(e.value)}
                        checked={radioValue == "New York"}
                    />
                    <label htmlFor="city3">New York</label>
                </div>
            </div>

            <div>
                <h3>DropDown</h3>
                <Dropdown
                    value={dropValue}
                    options={cities}
                    onChange={(e) => {
                        setDropValue(e.value);
                    }}
                    optionLabel="name"
                    placeholder="Select a City"
                />
            </div>
        </div>
    );
};

export default Demo;
