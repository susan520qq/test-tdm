import React from 'react';
import InputForm from '../component/InputForm';

const FormPage = () => {
    return <InputForm />;
}

export default formpage;