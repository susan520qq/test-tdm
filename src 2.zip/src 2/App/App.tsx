import View from '../View/View';

import testData from '../test.json';
import 'font-awesome/css/font-awesome.min.css';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';

import Calendar from '../Calendar/Calendar';
import React, { useState } from 'react';
import { Provider } from 'react-redux';
import createStore from '../Reducer';

import store from '../Reducer/index';
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import SopManagement from '../SopManagement/SopManagement.jsx';

const selected = {
  List: testData.list,
  Info: testData.info,
  Task: testData.task
}

const taskOption = testData.taskOption;

export const MyContext = React.createContext<{
  controlOpen: number | undefined,
  setControlOpen: (idx: any, open: any) => void,
  getControlOpen: (idx: any) => boolean
}>({
  controlOpen: undefined,
  setControlOpen: (idx: any, open: any) => { },
  getControlOpen: (idx: any): boolean => { return false }
});


function App() {

  // const [controlOpen,setControlOpen] = useState<{[idx:string]: boolean}>({})
  const [controlOpen, setControlOpen] = useState<number | undefined>(undefined)
  // 可以使用 useMemo
  // 從 task 中取得大節點資料
  const node = taskOption.filter((task) => {
    return task.dateSource === task.keyStage;
  });

  return (
    <Provider store={store}>
      <MyContext.Provider value={{
        controlOpen: controlOpen,
        setControlOpen: (idx: any, open: any): void => {
          // setControlOpen({...controlOpen, [idx+'']: open})
          setControlOpen(idx)
        },
        getControlOpen: (idx) => {
          // return controlOpen[idx]
          return controlOpen ? true : false
        }
      }}>
        <div className="App">
          <Router>
            <div>
              <span>
                <Link to={"/p2"}>1234</Link>
              </span>
            <Switch>
              <Route exact path="/">
                <View
                  // selected={selected}
                  // node={node}
                  // taskOptions={taskOption}
                />
              </Route>
              <Route exact path="/p2">
                <SopManagement />
              </Route>
            </Switch>
            </div>
          </Router>
        </div>
      </MyContext.Provider>
    </Provider>
  );


}

export default App;





