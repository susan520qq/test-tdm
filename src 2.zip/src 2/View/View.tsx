import React, { useCallback, useMemo, useRef, useState, Component } from 'react';
import { render } from 'react-dom';
import { AgGridReact } from "ag-grid-react";
import GridTable from '../SopManagement/GridTable';
import * as fh from '../utils/fetch-helper';
import TaskComponent from './TaskComponent'
import Detail from "./Detail";
import MyCalendar from "../Calendar/Calendar";
import { TabView, TabPanel } from 'primereact/tabview';
import { Button } from 'primereact/button';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faPen, faLink } from '@fortawesome/free-solid-svg-icons';
import '../styles/css/style.css';



const View = () => {
    const gridRef = useRef();
    const [isDetail] = useState<any>(false)

 
    const [rowData, setRowData] = useState([
        { id: 'aa', make: '0121', key: 'EDI-A08', model: 'Celica', desc: 'PR Coating(ArF/ EUV, UDO)', scount: 2 },
        { id: 'bb', make: '0125', key: 'EDI-A11', model: 'Mondeo', desc: 'PR Coating (KrF / Arf / Imme)', scount: 5 },
        { id: 'cc', make: '0124', key: 'EDI-A14', model: 'Boxster', desc: '', scount: 4 },
        { id: 'dd', make: '0126', key: 'EDI-D11', model: 'Angel', desc: 'Use for ETCH1 pre-hookup tools', scount: 6 },
        { id: 'ee', make: '0128', key: 'EDI-A17', model: 'Challanger', desc: 'PR Coating', scount: 0 },
        { id: 'ff', make: '0150', key: 'PHK', model: 'Kristin', desc: '', scount: 1 },
    ]);
    const [columnDefs, setColumnDefs] = useState([
        { headerName: 'Task ID', field: 'make' },
        { headerName: 'Key Stage', field: 'key' },
        { headerName: 'Task Name', field: 'model' },
        { headerName: 'Task Description', minWidth: 300, field: 'desc' },
        { headerName: 'SOP Count', field: 'scount',
            // cellRenderer: (tcount) =>
            //     `<a href="/${tcount.value}" >${tcount.value}</a>` 
            // cellRenderer: function (params) {
            //     return `<a href="https://www.google.com" target="_blank">` + params.value + `</a>`
            // }, 
            // cellRendererParams: {
            //     inRouterLink: `<a href="/${scount.value}" >${scount.value}</a>`,
            // }
  
        },
       
    ]);
    const defaultColDef = useMemo(() => {
        return {
            flex: 1,
            editable: true,
            sortable: true,
            filter: true,
        };
    }, []);
    const getRowId = useCallback(function (params) {
        return params.data.id;
    }, []);

    const updateSort = useCallback(() => {
        gridRef.current.api.refreshClientSideRowModel('sort');
    }, []);

    const updateFilter = useCallback(() => {
        gridRef.current.api.refreshClientSideRowModel('filter');
    }, []);

    
    //tabs
    const [activeIndex, setActiveIndex] = useState(0);

    const icon = <FontAwesomeIcon icon={faLink} />;

    let d = null
    if (isDetail) {
        d = <Detail
        ></Detail>
    }

    

    return (
        <div className="sop">
            <div className="tabs">
                <TabView activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                    <TabPanel header={<span>From Task<span className="tabs-icon sop">{icon}</span>TO <span className="font">SOP</span></span>}  >
                        <span className="title sop">SOP Summary Linked By Task</span>
                        
                        <div className='view' >
                            <div className='grid-table ag-theme-alpine'>
                                <AgGridReact
                                    ref={gridRef}
                                    rowData={rowData}
                                    columnDefs={columnDefs}
                                    defaultColDef={defaultColDef}
                                    animateRows={true}
                                    getRowId={getRowId}

                                    rowSelection={'multiple'}
                                    suppressRowClickSelection={true}
                                    suppressAggFuncInHeader={true}
                                ></AgGridReact>
                            </div>
                        </div>

                    </TabPanel>
                    <TabPanel header={<span>From SOP<span className="tabs-icon task">{icon}</span>TO <span className="font">Task</span></span> }  >
                        <span className="title task">Task Summary Linked By SOP</span>
                                               
                        Content II
                    </TabPanel>
                </TabView>

            </div> 
        </div>
    );
}



export default View;