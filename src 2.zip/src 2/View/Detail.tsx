import React from 'react'
import GridTable from '../SopManagement/GridTable';
import { Breadcrumbs } from '@mui/material';
import Link from '@mui/material/Link';
import '../styles/css/style.css';


const Detail: React.FC<any> = (props: any) => {

  const setisDetail = props.setisDetail

  const data = props.sortData(false);
  const columns = props.detailColumn;
  return <div className="table2nd" >

    {/* 這邊只是先寫個大概 */}
    <div className='title'>
        <Breadcrumbs aria-label="breadcrumb">
        <Link underline="hover">
        My schedule 01
        </Link>
        <Link
            underline="hover">
            T2
        </Link>
        </Breadcrumbs>

        <button onClick={()=>{setisDetail(false)}}><i className="fa fa-minus-square"></i></button>
    </div>
    <div className='table'>
    <GridTable
        dataDefs={{
            data: data
        }}
        columnDefs={{
            groups: columns
        }}
    />
    </div>
    </div>
}

export default Detail;