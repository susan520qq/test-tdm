import 'font-awesome/css/font-awesome.min.css';
import 'primereact/resources/themes/saga-blue/theme.css';
import 'primereact/resources/primereact.min.css';

import Calendar from '../Calendar/Calendar';
import React, { useState } from 'react';
import { Provider } from 'react-redux';
import createStore from '../Reducer';

import store from '../Reducer/index';
import ReactDOM from "react-dom";
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";
import View from '../SopManagement';
import SopManagement from '../SopManagement/SopManagement.jsx';
import Create from '../SopManagement/Create.jsx';

// const selected = {
//   List: testData.list,
//   Info: testData.info,
//   Task: testData.task
// }

// const taskOption = testData.taskOption;

export const MyContext = React.createContext<{
  controlOpen: number | undefined,
  setControlOpen: (idx: any, open: any) => void,
  getControlOpen: (idx: any) => boolean
}>({
  controlOpen: undefined,
  setControlOpen: (idx: any, open: any) => { },
  getControlOpen: (idx: any): boolean => { return false }
});


function App() {

  const [controlOpen, setControlOpen] = useState<number | undefined>(undefined)
 

  return (
    <Provider store={store}>
      <MyContext.Provider value={{
        controlOpen: controlOpen,
        setControlOpen: (idx: any, open: any): void => {
          // setControlOpen({...controlOpen, [idx+'']: open})
          setControlOpen(idx)
        },
        getControlOpen: (idx) => {
          // return controlOpen[idx]
          return controlOpen ? true : false
        }
      }}>
        <div className="App">
          <Router>
            <div>
              {/* <span>
                <Link to={"/0124"}>0124</Link>
              </span> */}
            <Switch>
              <Route exact path="/">
                <View/>
              </Route>
              <Route exact path="/0124">
                <SopManagement/>
              </Route>
              <Route exact path="/create">
                <Create/>
              </Route>
            </Switch>
            </div>
          </Router>
        </div>
      </MyContext.Provider>
    </Provider>
  );


}

export default App;





